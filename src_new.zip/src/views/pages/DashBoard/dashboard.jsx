import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate} from 'react-router-dom';
import { getBugs } from '../../../contollers/redux/bugslice';
import Card from '../../components/dashboard/card';

export default () => {
    const dispatch = useDispatch();
    const bugs = useSelector(state => state.bugs);
    const navigate = useNavigate();

    let highCount = 0;
    let midCount = 0;
    let lowCount = 0;

    function redirect() {
        navigate('/viewbugs')
    }

    if (bugs !== undefined) {
        highCount = filterBugs(1);
        midCount = filterBugs(2);
        lowCount = filterBugs(3);
    }

    function filterBugs(priority) {
        return bugs.filter((bug) => bug.priority === priority);
    }

    useEffect(() => {
        dispatch(getBugs());
    }, [bugs]);

    return (
        <div className='page-container'>
            <Card Priority={1} count={highCount.length} clicked={redirect} />
            <Card Priority={2} count={midCount.length} clicked={redirect} />
            <Card Priority={3} count={lowCount.length} clicked={redirect} />
        </div>
    );
};
