import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { signIn } from '../../../contollers/redux/authslice';
import './login.css';

const Login = () => {
    const dispatch = useDispatch();
    const [formInput, setFormInput] = useState({
        name: "",
        password: ""
    });

    function inputChanged(e) {
        setFormInput({
            ...formInput,
            [e.target.name]: e.target.value
        });
    }

    function submit(e) {
        e.preventDefault();
        dispatch(signIn(formInput));
    }

    return (
        <div className="loginBG">
            <form className='login-panel' onSubmit={submit}>
                <h1>Login:</h1>
                <input name='name' placeholder='Name' onChange={inputChanged} value={formInput.name}></input>
                <input name='password' type='password' placeholder='Password' onChange={inputChanged} value={formInput.password}></input>
                <button type='submit'>Login</button>
            </form>
        </div>
    );
};

export default Login;
