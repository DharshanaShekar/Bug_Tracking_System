import React,{useContext} from 'react';
import { Link, Routes,Route} from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';


import { signOut } from '../../contollers/redux/authslice'; // Corrected import path
import './sidebar.css';

const Sidebar = () => {
    const dispatch = useDispatch();
    const { auth } = useSelector(state => state);
    
    const handleSignOut = () => { // Renamed the function to handleSignOut
        dispatch(signOut());
    };

    return (
        <div className="sidebar">
            <Link className='nav-link' to="/"><h1 className='brand'>Bug-Tracker</h1></Link>
            <ul>
                <li><Link to='/' className='nav-link'>Dashboard</Link></li>
                <li><Link to='/viewbugs' className='nav-link'>View Bugs</Link></li>
                {auth.admin && <li><Link to='/create' className='nav-link'>Create Bug</Link></li>}
            </ul>
            <button className='nav-link logout' onClick={handleSignOut}>Logout</button> 
        
        </div>
    );

}

export default Sidebar;
