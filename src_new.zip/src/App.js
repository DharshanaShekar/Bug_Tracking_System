import React from 'react';
import { useSelector } from 'react-redux';
import { BrowserRouter as Router,Routes, Route } from 'react-router-dom'; // Fixed import statement
import Login from './views/pages/login/login';
import Sidebar from './views/sidebar/sidebar';
import DashBoard from './views/pages/DashBoard/dashboard'
import ViewBugPage from './views/pages/viewbug';
import CreateBug from './views/components/bugcreate/edit/bugform'

function App() {
    const { auth } = useSelector(state => state);

    return (
        <Router>
            {!auth.LoggedIn ? (
                <Login />
            ) : (
                <>     
                    <Sidebar />
                    <Routes>
                    <Route path='/' exact element={<DashBoard />} />
                    <Route path='/viewbugs' element={<ViewBugPage />} />
                    <Route path='/create' element={<div className='page-container'><CreateBug title="Create Bug" /></div>} />
                    </Routes>
                    
                </>
            )}
        </Router>  
    );
}

export default App;
